import discord
import os

client = discord.Client()

@client.event
async def on_ready():
	print('We have logged in as user {0.user}'.format(client)) 


#If bot the senses a message in the discord
@client.event
async def on_message(message):
  mention = message.author.mention
  if message.author == client.user: 
    return

  #Sending a message to the chat for verifying
  if message.content.startswith('/verify'):
    await message.delete()
    await message.channel.send(f'Thank you for verifying {mention}!')
    msg = message.content.replace("/verify ", "")
    await client.get_channel(829387859856982116).send(msg)
    
client.run(os.getenv('TOKEN'))



